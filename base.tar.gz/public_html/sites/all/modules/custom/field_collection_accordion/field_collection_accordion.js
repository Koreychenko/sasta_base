/**
 * @file
 * Provides js for tabs
 * @copyright Copyright(c) 2012 Previous Next Pty Ltd
 * @license GPL v2 http://www.fsf.org/licensing/licenses/gpl.html
 * @author Lee Rowlands larowlan at previousnext dot com dot au
 */


(function ($) {
/**
 * JS related to the tabs.
 */
Drupal.behaviors.fieldCollectionAccordion = {
  attach: function (context) {

    $('.field-collection-accordion', context)
      .once('accordion')
      .accordion({heightStyle : "content"});
  }
};

})(jQuery);


