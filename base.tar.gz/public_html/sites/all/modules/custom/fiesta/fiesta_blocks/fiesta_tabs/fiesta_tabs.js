(function($) {
  Drupal.behaviors.fiesta_tabs = {
    attach: function (context, settings) {
      $('.fiesta-tabs').tabs();
    }
  };
})(jQuery);
