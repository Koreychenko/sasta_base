(function($) {
  Drupal.behaviors.fiesta_accordion = {
    attach: function (context, settings) {
      $('.fiesta_accordion-items', context).accordion({heightStyle : "content"});
    }
  };
})(jQuery);
