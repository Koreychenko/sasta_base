(function($) {
  Drupal.behaviors.fiesta_slider = {
    attach: function (context, settings) {
      $(".field-collection-fiesta-slider",context).once().slick({
        dots: false,
        slidesToShow: 1,
        infinite: true,
        arrows: true,
        adaptiveHeight: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 1200,
      });
    }
  };
})(jQuery);
