(function($) {
  Drupal.behaviors.countdown = {
    attach: function (context, settings) {
        $('.countdown',context).each(function(){
            $(this).countdown({
                timestamp: (new Date()).getTime() + $(this).attr('data-days') * 24 * 60 * 60 * 1000,
            });
        });
    }
  };
})(jQuery);
