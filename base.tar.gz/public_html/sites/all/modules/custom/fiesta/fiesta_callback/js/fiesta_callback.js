Drupal.theme.prototype.fiestaCallbackModalHtml = function () {
  var html = '';
  html += '<div id="ctools-modal" class="ctools-modal-custom">';
  html += '  <div class="ctools-modal-content ctools-modal-custom-help-content">';
  html += '    <div class="modal-header">';
  html += '      <span class="popups-close"><a class="close" href="#">x</a></span>';
  html += '      <div id="modal-title" class="modal-title">&nbsp;</div>';
  html += '    </div>';
  html += '    <div id="modal-content" class="modal-content modal-content-custom"></div>';
  html += '  </div>';
  html += '</div>';
  return html;
}
