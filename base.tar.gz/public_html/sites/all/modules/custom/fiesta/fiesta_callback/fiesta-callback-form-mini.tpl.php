<div class="callback-form-wrapper">
  <div class="callback-form-top-text"><?php print $top_text; ?></div>
  <div class="callback-form-form clearfix">
    <div class="callback-form-left-column">
      <?php print $left_text; ?>
    </div>
    <div class="callback-form-right-column">
      <?php print $form; ?>
    </div>
  </div>
</div>
