<?php hide($form['additional_settings']); ?>
<?php hide($form['reusable']['reusable']); ?>
<?php print render($form['title']); ?>
<?php print render($form['title_field']); ?>
<?php print render($form['widget_content']); ?>
<div class="row">
  <div class="col-md-4">
    <?php print render($form['reusable']['reusable']); ?>
  </div>
  <div class="col-md-8">
    <?php print render($form['reusable']['admin_title']); ?>
  </div>
</div>
<?php print drupal_render_children($form); ?>
