(function($) {
  Drupal.behaviors.fiesta_editable = {
    attach: function (context, settings) {
      $('.editable-data',context).each(function() {
        $(this)[0].addEventListener("input", function(){
          $(this).removeClass('saved').addClass('changed');
        });
      });
      $('.contentedit-edit',context).click(function(e){
        e.preventDefault();
        $(this).closest('.editable-toolbar').find('.contentedit-save').show();
        $(this).hide();
        $(this).closest('.editable').find('.inline-editable').attr('contenteditable',true);
      });
      $('.contentedit-save',context).click(function(e){
        e.preventDefault();
        var parent = $(this).closest('.editable');
        var field_name = parent.attr('data-field-name');
        var field_language = parent.attr('data-field-language');
        var entity_type = parent.attr('data-entity-type');
        var cid = parent.attr('data-cid');
        var data = [];
        parent.find('[data-delta]').each(function(){
          data[$(this).attr('data-delta')] = $(this).html();
        });
        $.ajax({
          type: "POST",
          url: '/fiesta_editable/ajax',
          data: {cid : cid, data : data, field_name : field_name, field_language : field_language, entity_type : entity_type},
          success: function(data) {
            parent.find('.changed').addClass('saved').removeClass('changed').attr('contenteditable',false);
            parent.find('.editable-toolbar').find('.contentedit-save').hide();
            parent.find('.editable-toolbar').find('.contentedit-edit').show();

            setTimeout(function(){parent.find('.saved').removeClass('saved')},1000);
          },
        });
      });
    }
  };
})(jQuery);
