<div class="row">
  <div class="col-md-9">
    <?php  hide($form['actions']); ?>
    <?php  hide($form['options']); ?>
    <?php  hide($form['additional_settings']); ?>
    <?php print drupal_render_children($form); ?>
  </div>
  <div class="col-md-3">
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa-pencil fa fa-fw"></i> <?php print t('Publishing options'); ?></h3></div>
      <div class="panel-body">
        <?php print render($form['actions']); ?>
        <?php print render($form['author']['name']); ?>
        <?php print render($form['author']['date']); ?>
        <?php print render($form['options']['status']); ?>
        <?php print render($form['options']['promote']); ?>
        <?php print render($form['options']['sticky']); ?>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa-pencil fa fa-fw"></i> <?php print t('Path options'); ?></h3></div>
      <div class="panel-body">
      <?php print render($form['path']['pathauto']); ?>
        <?php print render($form['path']['alias']); ?>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa-pencil fa fa-fw"></i> <?php print t('Translations'); ?></h3></div>
      <div class="panel-body">
        <?php print render($form['translation']['status']); ?>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa-pencil fa fa-fw"></i> <?php print t('Additional'); ?></h3></div>
      <div class="panel-body">
        <?php print render($form['additional_settings']); ?>
      </div>
    </div>
  </div>
</div>
