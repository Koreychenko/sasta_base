 <div class="fiesta-admin">
 <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/admin">Fiesta Admin</a>
            </div>
            <ul class="nav navbar-right top-nav">
                <?php global $user; ?>
                <li><a href="/user/<?php print $user->uid; ?>" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php print $user->name; ?></a></li>
                <li class="logout"><a href="/user/logout" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-power-off"></i> <?php print t('Log out'); ?></a></li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">

                    <li>
                        <a href="/admin"><i class="fa fa-fw fa-dashboard"></i><?php print t('Dashboard'); ?></a>
                    </li>

                    <?php print render($page['sidebar']); ?>

                    <li><h4><?php print t('Settings'); ?></h4></li>
                    <li class="">
                        <a href="/admin/fiesta_theme_settings"><i class="fa fa-fw fa-cog"></i><?php print t('Theme settings'); ?></a>
                    </li>
                    <li class="">
                        <a href="/admin/fiesta_site_settings"><i class="fa fa-fw fa-cog"></i><?php print t('Site settings'); ?></a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="pull-right"><?php print render($tabs); ?></div>
                        <div class="pull-right"><?php print render($action_links); ?></div>
                        <h1 class="page-header">
                            <?php print $title; ?>
                        </h1>
                        <?php print $breadcrumb; ?>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <?php print render($messages); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                      <?php print render($page['content']); ?>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
</div>
