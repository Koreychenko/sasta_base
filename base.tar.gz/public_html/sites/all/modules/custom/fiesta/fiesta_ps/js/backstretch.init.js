(function($) {
  Drupal.behaviors.fiesta_ps_backstretch = {
    attach: function (context, settings) {
      $(".backstretch-block",context).each(function(){
        if ($(this).attr('data-image-src')) {
          $(this).backstretch($(this).attr('data-image-src'));
        }
      });
    }
  };
})(jQuery);
