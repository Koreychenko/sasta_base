(function($) {


  Drupal.behaviors.fiesta_ps = {
    attach: function (context, settings) {
    }
  };


  setTimeout(function() {
    $(window).trigger('resize').trigger('scroll');
  }, 500); // wait 500ms

  if (typeof Drupal.ajax != "undefined") {
   Drupal.ajax.prototype.commands.parallaxinitIPE = function(ajax, data, status) {
    if (Drupal.PanelsIPE.editors[data.key]) {
      Drupal.PanelsIPE.editors[data.key].initEditing(data.data);
      Drupal.PanelsIPE.editors[data.key].lockPath = data.lockPath;
    }
    Drupal.attachBehaviors();
    $('.parallax-mirror').hide();

    $('.parallax-bg').each(function(){
      $(this).css('background-image','url('+$(this).attr('data-image-src')+')');
    });
  };

   Drupal.ajax.prototype.commands.parallaxendIPE = function(ajax, data, status) {
    if (Drupal.PanelsIPE.editors[data.key]) {
      Drupal.PanelsIPE.editors[data.key].endEditing();
      $('.parallax-mirror').show();
       $(this).css('background-image',null);
    }
  };
}
})(jQuery);
